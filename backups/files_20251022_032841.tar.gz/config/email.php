<?php
/**
 * Email Configuration
 * 
 * IMPORTANT: This file contains sensitive credentials.
 * Never commit this file to version control!
 */

// SMTP Configuration for sending emails
define('SMTP_HOST', 'mail.kruit-en-kramer.nl');
define('SMTP_PORT', 587);
define('SMTP_SECURE', 'tls');
define('SMTP_AUTH', true);
define('SMTP_USER', 'ict@kruit-en-kramer.nl');
define('SMTP_PASS', 'your_smtp_password_here');  // UPDATE THIS with actual password

// Email sender information
define('FROM_EMAIL', 'ict@kruit-en-kramer.nl');
define('FROM_NAME', 'ICT Support - Kruit & Kramer');
define('REPLY_TO_EMAIL', 'ict@kruit-en-kramer.nl');

// IMAP Configuration for receiving emails (email-to-ticket feature)
define('IMAP_HOST', '{mail.kruit-en-kramer.nl:993/imap/ssl}INBOX');
define('IMAP_USER', 'ict@kruit-en-kramer.nl');
define('IMAP_PASS', 'your_imap_password_here');  // UPDATE THIS with actual password
define('IMAP_PORT', 993);
define('IMAP_SECURE', 'ssl');

// Email processing settings
define('EMAIL_PROCESS_LIMIT', 50);
define('EMAIL_MARK_AS_READ', true);
define('EMAIL_DELETE_AFTER_PROCESS', false);

// Email notification settings - DISABLED for development
define('ENABLE_EMAIL_NOTIFICATIONS', false);  // Set to true when email is configured
define('NOTIFY_ON_TICKET_CREATE', true);
define('NOTIFY_ON_TICKET_ASSIGN', true);
define('NOTIFY_ON_STATUS_CHANGE', true);
define('NOTIFY_ON_COMMENT_ADD', true);
define('NOTIFY_ON_TICKET_RESOLVE', true);

// Email template settings
define('EMAIL_FOOTER', "\n\n---\nICT Support - Kruit & Kramer\nEmail: ict@kruit-en-kramer.nl\nPortal: http://localhost/ticketportaal");
